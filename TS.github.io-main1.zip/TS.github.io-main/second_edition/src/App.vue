<template>
  <router-view />
</template>

<style lang="less">
.van-field__control {
  margin-left: 20px;
}
.van-field__control::placeholder {
  color: darkslategray;
  border: none;
}
body {
  overflow-y: hidden;
}
.van-button {
  font-size: 50px;
}
</style>
